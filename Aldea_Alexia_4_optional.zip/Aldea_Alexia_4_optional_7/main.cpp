#include <iostream>
#include <fstream>
#include <vector>
#define INF 1024

using namespace std;

ifstream f("riremito.in");
ofstream g("riremito.out");

int n,k;
vector<pair<int, int>> grefa[INF + 2];
long long rez[INF + 2][2];

void DFS(int nod, int tata, long long drum) 
{
    for (pair<int, int> i: grefa[nod]) 
    {
        if (i.first == tata)  continue; 

        DFS(i.first, nod, drum + i.second);

        rez[nod][1] = max(rez[nod][1], rez[i.first][1] + i.second);
        rez[nod][0] += rez[i.first][0] + i.second + min(rez[i.first][1] + i.second, drum);
    }

    rez[nod][0] -= (rez[nod][1] < drum) ? rez[nod][1] : drum;
}

long long solutie(int x)
{
    for (int i = 1; i <= n; i++)
        rez[i][0] = rez[i][1] = 0;

    DFS(x, -1, 0);
    return rez[x][0];
}

int main()
{
    f >> n;

    for (int i = 1; i < n; i++) {
        int x, y, z;
        f >> x >> y >> z;
        grefa[x].push_back({y, z});
        grefa[y].push_back({x, z});
    }

    f >> k;
    for (int i = 1; i <= k; i++)
    {
        int x;
        f >> x;
        g << solutie(x) << endl;
    }

    return 0;
}

//Alg rezolva problema gasirii sumei costurilor celui mai lung drum
//care trece prin toate nodurile, intr-un arbore.
//Folosim parcurgerea DFS pentru a rezolva problema. Incepem din radacina si
//ii vizitam toti copiii recursiv. Solutia este implementata prin retinerea
//a 2 valori pt fiecare nod:
//->rez[i][0] este suma costurilor dintre mai lung drum prin toate nodurile
//si al doilea cel mai lung drum prin toate nodurile, ce are radacina in i
//-> rez[i][1] este costul celui mai lung drum de la un nod in subaorborele
//ce are radacina in i
//Apoi, updatam rez[i][0] si rez[i][1] pentru fiecare nod care traverseaza
//arborele si returneaza rez[x][0] pentru nodul de start al query-ului x. Apoi,
//face acest lucru pt toate query-urile.