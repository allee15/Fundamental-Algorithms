#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>

using namespace std;


class Solution
{
public:
    //lista dea adiacenta a unui nume impreuna cu emailurile sale, emailurile sunt noduri
    unordered_map<string, vector<string>> grefa;
    //vector de emailuri vizitate
    unordered_set<string> viz;
    //rezultatul dupa ce facem merge pe emailuri
    vector<vector<string>> rez;

    void DFS(string& email)
    {
        viz.insert(email);
        rez.back().push_back(email);

        for(auto& adjEmail : grefa[email])
            if(!viz.count(adjEmail)) DFS(adjEmail);
    }
    vector<vector<string>> accountsMerge(vector<vector<string>>& matr)
    {
        for(auto& acc : matr)
            //cream un graf ce are emailurile drept noduri
            for(int i = 2; i < acc.size(); i++)
                //adaugam muchie intre nodurile adiacente ale aceluiasi cont
                grefa[acc[i]].push_back(acc[i-1]),
                        grefa[acc[i-1]].push_back(acc[i]);

        for(auto& acc : matr)
            if(!viz.count(acc[1]))
            { // daca un email al unui cont nu a fost vizitat
                //atunci cream un cont nou, inseram numele persoanei
                //facem dfs ca sa i gasim toate emailurile si le adaugam la lista
                rez.push_back({acc[0]});
                DFS(acc[1]);
                //la final, sortam emailurile
                sort(begin(rez.back())+1, end(rez.back()));
            }

        return rez;
    }
};
//ne formam un graf aciclic si neorientat, cu emailurile ca si noduri. Il reprezentam
//sub forma unei liste de adiacente. fiecare email va avea muchii cu celelalte emailuri,
//din acelasi cont.
//parcurgem fiecare cont, luam fiecare email, pe rand si traversam muchiile acelui email.
//pentru aceasta parcurgere, vom folosi dfs.
//vom sorta emailurile gasite mereu si, le vom sorta si in lista finala. de asemenea,
//fiecare email adagat in lista va fi marcat ca fiind vizitat
//la final, returnam lista gasita cu emailurile merge-uite