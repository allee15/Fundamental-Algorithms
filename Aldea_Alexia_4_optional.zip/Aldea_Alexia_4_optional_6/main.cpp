#include <fstream>
#include <queue>
#include <vector>

using namespace std;

const int INF = 1024;


ifstream f("dbz.in");
ofstream g("dbz.out");

int dp[1505],p[1505],x,y,z,c,n,m,ans;
vector <pair <int, int> > e[1505];
priority_queue <pair <int, int> > pq;

int main()
{
    f >> n >> m;
    for (int i = 0;i < m;i++)
    {
        f >> x >> y >> z;
        e[x].push_back({y, z});
        e[y].push_back({x, z});
    }
    for (int i = 1;i <= n;i++)
    {
        for (int j = 1;j <= n;j++)
        {
            dp[j] = INF;
            p[j] = -1;
        }

        dp[i] = 0;
        pq.push({0, i});

        while (!pq.empty())
        {
            c = pq.top().first;
            z = pq.top().second;
            pq.pop();

            if (dp[z] != -c) continue;
            for (auto j : e[z])
            {
                x = j.first;
                y = j.second;

                if (dp[x] > dp[z] + y)
                {
                    dp[x] = dp[z] + y;
                    p[x] = p[z];
                    pq.push({-dp[x], x});
                    if (z == i)
                        p[x] = x;
                }
            }
        }
        ans = INF;

        for (int j = 1;j <= n;j++)
        {
            for (auto k : e[j])
            {
                x = k.first;
                y = k.second;
                if ((p[x] == p[j]) || (i == j && p[x] == x) || (i == x && p[j] == j)) continue;
                ans = min(ans, dp[j] + y + dp[x]);
            }
        }
        if (ans == INF)
            g << "-1 ";
        else
            g << ans << " ";
    }
    return 0;
}

//Alg rezolva problema gasirii distantei minime dintre oricare 2 noduri
//care nu sunt direct conectate, intr-un graf.
//Ne vom folosi de alg lui Dijkstra. Folosind o coada de cost negativ, aflam
//distanta minima dintre toate nodurile si nodurile lor tata.
//Apoi, trecem prin toate nodurile si verificam daca un nod are tata diferit
//fata de vecinii sai. In caz afirmativ, updatam ans cu distanta minima dintre
//acesti vecini.