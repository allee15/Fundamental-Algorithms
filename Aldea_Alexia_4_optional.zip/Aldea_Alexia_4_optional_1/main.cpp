#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#define dimensiune 100001

using namespace std;

ifstream f("transport2.in");
ofstream g("transport2.out");

int n,m, dreapta, stanga, mijloc;
vector<vector<pair<int,int>>> grefa(dimensiune);
vector<int> viz(dimensiune);

int BFS(int x)
{
    queue<int> q;
    for(int i=1;i<=n;i++)
        viz[i]=0;

    q.push(1);
    viz[1]=1;

    while(!q.empty())
    {
        int front= q.front();
        q.pop();
        if(front==n)
            return 1;


        for(auto i: grefa[front])
        {
            if(!viz[i.first] && i.second >=x)
            {
                q.push(i.first);
                viz[i.first] = 1;
            }
        }
    }
    return 0;
}

int main()
{
    f>>n>>m;
    for(int i=0;i<m;i++)
    {
        int x,y,c;
        f>>x>>y>>c;
        grefa[x].push_back(make_pair(y,c));
        grefa[y].push_back(make_pair(x,c));
        dreapta = max(dreapta,c);
    }
    
    stanga = 1;
    while(stanga<= dreapta)
    {
        mijloc = (stanga+dreapta) / 2;
        
        if(BFS(mijloc) == 1)
            stanga = mijloc +1;
        else
            dreapta = mijloc -1;
    }
    
    g<<dreapta;

    f.close();
    g.close();
    return 0;
}

//folosim parcurgerea bfs pentru a gasi costul maxim pentru arborele
//partial minim al unui graf neorientat.
//Programul foloseste cautarea binara, unde ne setam 2 puncte de plecare,
//stanga si dreapta si mijlocul. In fiecare iteratie, programul verifica
//daca weight-ul arborelui este >= mijloc. In caz afirmativ, programul
//misca stanga catre mijloc, iar in caz contrar, muta dreapta spre mijloc
//Functia BFS este folosita pentru a verifica daca graful este conectat,
//unde x este limita de cost pentru a verifica daca exista un drum intre
//primul si ultimul nod si daca costul muchiilor >= x
//In final, vom afisa costul maxim in arborele partial minim.