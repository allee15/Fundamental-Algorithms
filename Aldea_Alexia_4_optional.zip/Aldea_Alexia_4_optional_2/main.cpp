#include <iostream>
#include <fstream>
#include <algorithm>
#define MAX_TABLA 19683
#define LIBER 0
#define X 1
#define O 2
#define WIN 0
#define DRAW 1
#define LOSE 2
#define NETERMINAT -1

using namespace std;

ifstream f("xsizero.in");
ofstream g("xsizero.out");

int rezultat[MAX_TABLA], mat[3][3], p3[10];

int minim( int a, int b )
{
    if(a<b) return a;
    return b;
}

int maxim( int a, int b )
{
    if(a>b) return a;
    return b;
}

int terminat()
{
    for ( int l = 0; l < 3; l++ )
        if ( mat[l][0] != LIBER && mat[l][0] == mat[l][1] && mat[l][0] == mat[l][2] )
            return mat[l][0] == X ? WIN : LOSE;

    for (int c = 0; c < 3; c++ )
        if ( mat[0][c] != LIBER && mat[0][c] == mat[1][c] && mat[0][c] == mat[2][c] )
            return mat[0][c] == X ? WIN : LOSE;

    if ( mat[1][1] != LIBER && mat[1][1] == mat[0][0] && mat[1][1] == mat[2][2] )
        return mat[1][1] == X ? WIN : LOSE;

    if ( mat[1][1] != LIBER && mat[1][1] == mat[0][2] && mat[1][1] == mat[2][0] )
        return mat[1][1] == X ? WIN : LOSE;

    for ( int l = 0; l < 3; l++ )
        for (int  c = 0; c < 3; c++ )
            if ( mat[l][c] == LIBER )
                return NETERMINAT;

    return DRAW;
}

int calcul( int tabla, int x, int o )
{
    if ( rezultat[tabla] != -1) return rezultat[tabla];

    int r = terminat();
    if ( r != NETERMINAT )
    {
        rezultat[tabla] = r;
        return r;
    }

    if ( x == o ) r = LOSE;
    else r = WIN;

    for ( int l = 0; l < 3; l++ )
        for (int c = 0; c < 3; c++ )
            if ( mat[l][c] == LIBER )
            {

                if ( x == o )
                {
                    mat[l][c] = X;
                    r = minim( r, calcul( tabla + X * p3[l * 3 + c], x + 1, o ) );
                    mat[l][c] = LIBER;
                }
                else
                {
                    mat[l][c] = O;
                    r = maxim( r, calcul( tabla + O * p3[l * 3 + c], x, o + 1 ) );
                    mat[l][c] = LIBER;
                }
            }

    rezultat[tabla] = r;
    return r;

}

int main()
{
    int x, o,a;
    char ch;
    p3[0] = 1;
    int test=1;

    for (int i = 1; i <= 9; i++ )
        p3[i] = p3[i - 1] * 3;

    for (int tabla = 0; tabla < p3[9]; tabla++ )
        rezultat[tabla] = -1;

    int tabla;
    while(f>>ch)
    {
        tabla=0;
        o=x=0;

        for (int l = 0; l < 3; l++ )
        {
            for ( int c = 0; c < 3; c++ )
            {
                if ( ch == '.' )
                    a = LIBER;
                else
                {
                    if ( ch == 'X' )
                        a = X;
                    else
                        a = O;
                }
                mat[l][c] = a;
                tabla += a * p3[l * 3 + c];
                x += (a == X);
                o += (a == O);
                f>>ch;
            }
            f>>ch;
        }
        g<<"Testul #"<<test<<": ";
        if ( x - o < 0 || x - o > 1 )
            g<<"invalid"<<endl;
        else
        {
            rezultat[tabla] = calcul( tabla, x, o );
            if ( rezultat[tabla] == WIN )
                g<<"win"<<endl;
            else
            {
                if ( rezultat[tabla] == LOSE )
                    g<<"lose"<<endl;
                else
                    g<<"draw"<<endl;
            }
        }
        test++;
    }

    f.close();
    g.close();
    return 0;

}

//Alg o prezentare minimala a jocului x si zero. Poate afisa daca x castiga,
//pierde, daca este remiza sau daca jocul este invallid prin inputul pe
// care il primeste de la tastatura.
//Pentru inceput, array ul p3 este folosit pt a genera starea unui joc
//folosindu-se de un sistem de 3 numere.
//array ul rezultat retine rezultatele jocurilor care au fost jucate deja
//Tot codul se invarte in jurul subprogramului calcul. Acesta ia starea
//curenta a jocului, cati X si cati 0 au fost jucati si returneaza rezultatul
//jocului, stocat in array-ul rezultat. Daca nu s-a realizat jocul,
//se va simula automat prin a se autoapela recursiv cu urmatoarele posibile
//stari ale jocului
//Functiile minim si maxim returneaza minimul, respectiv maximul dintre 2 inturi.
//Functia terminat verifica daca jocul s-a terminat si returneaza scorul
//acestuia.