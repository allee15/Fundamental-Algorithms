#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Solution{
public:
    int longestCommonSubsequence(string text1, string text2)
    {
        int nr=0;
        if(text1.size() >= text2.size())
        {
            vector<vector<int>>secv(text2.size()+1, vector<int>(text1.size()+1,0));
            for(int i=0;i<text2.size();i++)
                for(int j=0;j<text1.size();j++)
                    if(text2[i] == text1[j])
                        secv[i+1][j+1]= secv[i][j]+1;
                    else
                        secv[i+1][j+1]= max(secv[i][j+1], secv[i+1][j]);

            nr = secv[text2.size()][text1.size()];
        }
        else
        {
            vector<vector<int>>secv(text1.size()+1, vector<int>(text2.size()+1,0));
            for(int i=0;i<text1.size();i++)
                for(int j=0;j<text2.size();j++)
                    if(text1[i] == text2[j])
                        secv[i+1][j+1]= secv[i][j]+1;
                    else
                        secv[i+1][j+1]= max(secv[i][j+1], secv[i+1][j]);

            nr = secv[text1.size()][text2.size()];
        }

        return nr;
    }
};

//intai vrem sa verificam care dintre cele 2 stringuri date in input este
//mai mare. Apoi, vom face 2 foruri, primul fiind dupa stringul mai mic.
//Daca gasim 2 caractere egale in cele 2 stringuri, crestem pe diagonala
// nr de caractere egale de pana acum din subsecventa.
//In caz contrar, salvam in matrice pe diagonala, maximul dintre urmatorul
//contor din primul cuvant si urm contor din al doilea cuvant
// La final, salvam in variabila nr dimensiunea celei mai lungi secvente,
// care se va afla pe ultima pozitie din matricea secv
