#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

class Solution {
public:
    int shortestPathLength(vector<vector<int>>& graph) {
        int n = graph.size();
        queue<pair<int, int>> q;
        vector<vector<bool>> viz(n, vector<bool>(1<<n));

        for (int i = 0; i < n; ++i) {
            q.emplace(i, 1<<i);
            viz[i][1<<i] = true;
        }

        for (int i = 0; q.size(); ++i)
            for (int j = q.size(); j; --j) {
                auto [u, mask] = q.front(); q.pop();
                if (mask == (1<<n) - 1) return i;
                for (auto& v : graph[u])
                    if (!viz[v][mask | 1<<v]) {
                        q.emplace(v, mask | 1<<v);
                        viz[v][mask | 1<<v] = true;
                    }
            }
        return -1;
    }
};

//Alg cauta cel mai scurt drum intr-un graf. Problema se defineste cu un
//graf cu un set de noduri si un set de muchii care conecteaza acele noduri.
//Goal-ul este sa gasim cel mai scurt drum care viziteaza toate nodurile
//rafului.
//graph -> lista de adiacenta a grafului
// cu q tinem evidenta nodurilor viiztate, iar in viz le si marcam
//initial, toate nodurile se afla in q cu starea corespunzatoare (1<<i), iar
//state ul este marcat ca si vizitat
//apoi, in cele 2 foruri, parcurgem graful. Primul for merge cat timp avem
//ceva in coada, iar cel de-al doilea itereaza cat timp avem ceva in coada,
//la momentul respectiv
//In al doilea for, vecinii nodului curent au fost vizitati, iar starea
//sa este updatata. Noua stare reprezinta setul de noduri viztate pana acum,
//stocate in mask|1<<v.
//daca starea curenta == cu starea finala (toate nodurile au fost vizitate),
//functia returneaza numarul de pasi facuti pentru a ajunge la aceasta stare.
//Daca coada este goala iar starea finala nu a fost atinsa, functia va
//returna -1.