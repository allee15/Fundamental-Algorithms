#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("johnie.in");
ofstream g("johnie.out");

vector<vector<pair<int, int>>>grefa;
vector<int>grad, viz, drum;

int n, m, start;

void DFS(int nod, vector<int>& drum, vector<vector<int>>& rez){
    while(!grefa[nod].empty())
    {
        pair<int, int>pereche = grefa[nod].back();
        grefa[nod].pop_back();
        
        int vecin = pereche.first;
        int contor = pereche.second;
        
        if(!viz[contor])
        {
            viz[contor] = 1;
            DFS(vecin, drum, rez);
        }
    }
    
    if(nod == start)
    {
        if (drum.size()) 
        {
            rez.push_back(drum);
            drum.clear();
        }
    }
    else
        drum.push_back(nod);
}

int main() 
{
    f >> n >> m;
    
    vector<vector<int>>rez;
    
    viz.assign(n+m+1,0);
    grad.assign(n+1,0);
    grefa.resize(n+1);
    
    int a, b, contor = 0;
    
    for(int i=0; i<m; i++)
    {
        f >> a >> b;
        grefa[a].push_back({b, contor});
        grefa[b].push_back({a, contor});
        
        contor++;
        grad[a]++;
        grad[b]++;
    }
    // cream un nod de start si il conectam cu nodurile care au grad impar
    // (capetele lanturilor euleriene)
    start = 0;
    for(int i=1; i<=n; i++)
        if(grad[i] % 2 == 1)
        {
            grefa[start].push_back({i, contor});
            grefa[i].push_back({start, contor});
            contor++;
        }

    DFS(start, drum, rez);
    g<<rez.size()<<endl;

    for(int i=0; i<rez.size(); i++)
    {
        g<<rez[i].size()<<" ";
        for(int j=0; j<rez[i].size(); j++)
            g<<rez[i][j]<<" ";
        g<<endl;
    }

    return 0;
}
//complexitate O(n+m)

//Folosim parcurgerea DFS pentnru a gasi cicluri euleriene intr-un graf
//neorientat.
//grefa -> lista de adiacenta a grafului
//grad -> gradul fiecarui nod
//viz -> nodurile vizitate/nevizitate
//Apelam functia DFS din main. Face o parcurgere DFS pentru a vizita toate
//muchiile si tine minte toate nodurile vizitate intr-un vector numit drum
//Cand ajunge la nodul de start, iar vectorul drum are elemente in el, inseamna
//ca s-a gasit un ciclu eulerian si ca a fost stocat in vectorul rez.
//Inainte de apelarea subprogramului DFS, programul creeaza un nod aditional
//de start si-l conecteaza cu toate nodurile care au grad impar. Facem acest
//lucru pentru a ne asigura ca graful este semi-eulerian si ca subpr DFS
//va putea gasi toate ciclurile euleriene.
//Afisam numarul de cicluri euleriene si, pentru fiecare ciclu, numarul de
//noduri din el si nodurile efective.