#include <iostream>
#include <fstream>
#include <climits>
#include <vector>
#include <queue>

using namespace std;

ifstream f("drumuri2.in");
ofstream g("drumuri2.out");

int n, m, start, stop, flow_maxim;

vector<int>grefa[202];
vector<int>tata, viz;

int capacitate[202][202];
queue<int>q;

int BFS(){
    viz.assign(2 * n + 2, 0);
    tata.assign(2 * n + 2, 0);
    
    while(!q.empty())
        q.pop();
    
    q.push(start);
    tata[start]=0;
    viz[start]=1;
    
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        
        if(nod == 2 * n + 1)
            return 1;

        for(auto neighbour:grefa[nod])
            if(viz[neighbour] == 0 && capacitate[nod][neighbour] > 0)
            {
                q.push(neighbour);
                viz[neighbour] = 1;
                tata[neighbour] = nod;
            }
    }

    return viz[2*n+1];
}

int main()
{
    f>>n>>m;
    int a, b;

    for(int i=0; i<m; i++)
    {
        f>>a>>b;
        grefa[a].push_back(b+n);
        grefa[b + n].push_back(a);

        capacitate[a][b+n] = 1;
    }

    // setam un start si un stop pentru a face cuplajele
    start = 0;
    stop = 2 * n + 1;

    for(int i=1; i<=n; i++)
    {
        grefa[start].push_back(i);

        capacitate[start][i] = 1;

        grefa[i].push_back(n + i);
        grefa[n+i].push_back(i);

        capacitate[n+i][i] = 1;
        grefa[n+i].push_back(stop);
        capacitate[n+i][stop] = 1;
    }

    while(BFS())
    {
        for(int i = n + 1; i <= 2 * n; i ++)
        {
            if(!viz[i]) continue;
            tata[stop] = i;
            int flow = INT_MAX;

            for(int nod = stop; nod != start; nod = tata[nod])
                flow = min(flow, capacitate[tata[nod]][nod]);

            if(flow == 0) continue;

            for(int nod = stop; nod != start; nod = tata[nod])
            {
                capacitate[tata[nod]][nod] -= flow;
                capacitate[nod][tata[nod]] += flow;
            }
            flow_maxim += flow;
        }
    }
    g<<n-flow_maxim;
    return 0;
}
//complexitate O(E*V^2)

//Folosim parcurgerea BFS pentru a gasi flow-ul maxim intr-un graf
//neorientat.
//grefa -> lista de adiacenta a grafului
//capacitate -> capacitatea fiecarei muchii
//In BFS, cautam cel mai scurt drum dintre start si stop, tinand minte
//capacitatea fiecarei muchii. Apoi, gaseste flow-ul minim pentru acest drum
//, updateaza capacitatile muchiilor si tine minte flow-ul total.
//startul a fost luat de la 0, iar stopul de la 2*n+1, pentru ca flow-ul
//maxim sa se afle intre ele
//Loop-ul while continua pana cand functia BFS returneaza 0, indicand
//faptul ca nu mai exista niciun flow intre start si stop.
//In final, afiseaza in fisierul g numarul de matchuiri, care este = cu
//nr de noduri din graf - valoarea flow-ului maxim.