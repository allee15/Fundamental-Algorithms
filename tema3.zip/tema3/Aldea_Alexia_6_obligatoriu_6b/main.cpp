#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Solution{
public:
    string alegere(string &s1, string &s2, string &s3)
    {

        string sol=s1;
        if(sol.size()>s2.size())
            sol=s2;
        if(sol.size()>s3.size())
            sol=s3;

        return sol;
    }

    string shortestCommonSupersequence(string str1, string str2)
    {
        vector<vector<string>> secv(str1.size()+1, vector<string>(str2.size()+1,""));
        for(int i=1;i<=str1.size();i++)
            secv[i][0]=secv[i-1][0]+ str1[i-1];

        for(int i=1;i<=str2.size();i++)
            secv[0][i]=secv[0][i-1]+str2[i-1];

        for(int i=1;i<=str1.size();i++)
        {
            for(int j=1;j<=str2.size();j++)
            {
                string t;
                if(str1[i-1] == str2[j-1])
                    t=secv[i-1][j-1]+str1[i-1];
                else
                    t=secv[i-1][j-1]+str1[i-1]+str2[j-1];

                string t1=secv[i-1][j]+str1[i-1];
                string t2= secv[i][j-1]+str2[j-1];
                secv[i][j] = alegere(t1,t2,t);
            }
        }

        return secv[str1.size()][str2.size()];
    }
};
//in subprogramul alegere facem practic metoda paharelor pentru a afla
//care string este mai mic dintre s1,s2,s3 si l returnam pe cel mai mic
//in subprogramul principal, in matricea secv practic pe linia i si col 0
//vom salva fiecare caracter din stringul str1, iar pe linia 0 si coloana i,
//vom salva fiecare caracter din str2. Apoi parcurgem matricea (care e
// str1.size()*str2.size()). Daca avem 2 caractere anterioare egale,
//salvam in contorul t secventa pana la el+caracterul curent. Altfel,
//salvam in t secventa pana la el + caracterul curent din str1 + caracterul
//curent din str2
//in t1 apoi vom salva secventa pana la el+ caracterul din str1 anterior.
//analog procedam si pt t2, pt str2. Apoi, comparam t,t1,t2 prin apelarea
//subprogramului alegere, care ne va salva in secv pe pozitia curenta,
//secventa de lungime minima
//la final, ultimul caracter al matricei secv este si secventa de lungime
//minima, pe care o vom si returna