#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>
#include <unordered_map>

using namespace std;

class Solution {
public:
    vector<vector<int>> validArrangement(vector<vector<int>>& pairs) {
        unordered_map<int, vector<int>> grefa;
        unordered_map<int, int> grad;

        int start = 0;
        for (auto& edge : pairs) {
            grefa[edge[0]].push_back(edge[1]);
            ++grad[edge[0]];
            --grad[edge[1]];
            start = edge[0];
        }

        for (auto& [k, v] : grad)
            if (v == 1) start = k;

        vector<int> drum;
        stack<int> s;
        s.push(start);
        while (s.size()) {
            while (grefa[s.top()].size()) {
                int x = s.top();
                s.push(grefa[x].back());
                grefa[x].pop_back();
            }
            drum.push_back(s.top()); s.pop();
        }
        reverse(drum.begin(), drum.end());
        vector<vector<int>> rez;
        for (int i = 0; i < drum.size()-1; ++i)
            rez.push_back({drum[i], drum[i+1]});
        return rez;
    }
};
//complexitate: O(n)

//primim ca input o matrice de perechi de inturi si vrem sa returnam o
//aranjare valida a acestora. Pentru a realiza acest lucru, ne vom folosi
//de sortarea topologica si de parcurgerea DFS.
//incepem prin a ne crea 2 "dictionare" neordonate: intr-unul stocam muchiile
//fiecarui nod, iar in celalalt gradul fiecarui nod
//pentru a gasi un nod de start, iteram asupra celui de-al 2-lea dictionar
//si verificam daca primul nod are gradul ==1
//apoi facem DFS prin folosirea unui stack pentru a itera printre muchii,
//pusham nodurile pe un stack, iar atunci cand muchiie unui nod se termina,
//adaugam nodul la vectorul numit drum. Continuam acest proces pana cand se
//goleste sstack-ul.
//la final, da reverse la vectorul de drum si pune fiecare pereche de noduri
//ca elemente intr-un nou vector, rez si ii da return la final