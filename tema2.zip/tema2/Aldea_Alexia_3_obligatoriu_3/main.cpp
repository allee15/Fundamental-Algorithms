#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

ifstream f("cuvinte.in");

void nuamideedenume( pair<int, string> a,  pair<int, string> b,vector<pair<int, pair<int,int>>>&grefa)
{  // adaugam in graful nostru tuplul: (distanta de editare, (primul cuvant, al doilea cuvant))
    int ceva[a.second.length()+1][b.second.length()+1];
    for(int i=0;i<a.second.length()+1;i++)
        ceva[i][0]=i;
    for(int i=0;i<b.second.length()+1;i++)
        ceva[0][i]=i;
    for(int i=1;i<a.second.length()+1;i++)
        for(int j=1;j<b.second.length()+1;j++)
        {
            if(a.second[i-1] == b.second[j-1])
                ceva[i][j]=ceva[i-1][j-1];
            else
                ceva[i][j]=min(ceva[i][j-1], min(ceva[i-1][j],ceva[i-1][j-1]))+1;
        }
    grefa.push_back(make_pair(ceva[a.second.length()][b.second.length()], make_pair(a.first,b.first)));
}

void Kruskal(int k, int nr, vector<pair<int, pair<int,int>>> grefa, vector<pair<int, string>> words)
{ // cream vectorul responsabil pentru retinerea claselor cuvintelor -> initial fiecare cuvant are propria clasa

    vector<int> clase;
    clase.resize(nr+1);
    for(int i=0;i<nr;++i)
        clase[i]=i;

    // pentru a ajunge la fix k clase, trebuie sa facem length - k pasi de legare a cuvintelor/grupurilor
    // de cuvinte(unde nr este numarul de cuvinte, iar k este numarul de clase disponibile pt organizarea cuvintelor)
    int pas=nr-k,i=0;
    while (i<=pas)
    { // din moment ce graph este un vector ordonat crescator dupa distanta de editare dintre cuvinte, mereu vom lua cuvintele cu distanta de editare minima
        auto muchie=grefa[i]; //auto conversteste muchie la ce tip trebuie; am luat cea mai mica muchie
        if(clase[muchie.second.first] != clase[muchie.second.second])  // verificam ca cele doua cuvinte sa fie din clase diferite
        {
            for(int j=0;j<nr;j++) // daca da, alipim toate cuvintele din a doua clasa in prima clasa
                if(clase[j]==clase[muchie.second.second])
                    clase[j]=clase[muchie.second.first];
        }
        else // crestem length-ul doar daca muchia pe care am luat-o apartine leaga doua noduri din aceeasi clasa
        // ---> trebuie neaparat sa facem nr - k pasi(daca nu cresteam length, am fi putut face nr-k-1 pasi si nu e corect)
            pas++;

        i++;
    }

    vector<int>rezultat;
    for(int j = 0; j < nr; ++j)
    {
        bool ok = true;
        for(auto cls: rezultat)
            if(clase[j] == cls)
                ok = false;
        if(ok) {
            rezultat.push_back(clase[j]);
        }
    }

    for(auto rez: rezultat) {  // parcurgem toate clasele existente si afisam cuvintele in functie de clasa respectiva -> pt organizare
        for(int j = 0; j < nr; ++j) {
            if(rez == clase[j]) { // afisam cuvintele dupa clasele create
                cout<<words[j].second<<" ";
            }
        }
        cout<<endl;
    }
    // ca sa afisam distanta minima dintre clasele create, trebuie sa afisam urmatoarea muchie care vine la rand in graph-ul nostru dupa ce am creat clasele respective
    cout<<grefa[pas].first<<endl;
}

int main()
{
    int k;
    cout<<"k= ";
    cin>>k;
    vector<pair<int, string>> words;
    vector<pair<int, pair<int,int>>> grefa;
    int nr=0;
    string s;
    while(f>>s) // citim toate cuvintele care ne vin din fisier si le punem intr-un vector, retinem numarul de cuvinte citite in nr
    {
        words.push_back(make_pair(nr,s));
        ++nr;
    }
    // parcurgem vectorul de cuvinte si pt fiecare pereche de doua cuvinte cream muchia cu ponderea egala cu distanta de editare
    for(int i=0;i<nr-1;++i)
        for(int j=i+1;j<nr;++j)
        {// alg care creaza muchia in graful nostru(in listele de adiacenta)
            nuamideedenume(words[i],words[j],grefa);
        }

    // sortam vectorul crescator dupa distanta de editare ---> functioneaza deoarece sort-ul o sa mearga in primul pair din vector
    // si o sa verifice first mai intai care e distanta de editare
    sort(grefa.begin(),grefa.end());
    Kruskal(k,nr,grefa,words);

    return 0;
}
// the Levenshtein distance between two words is the minimum number of single-character edits (insertions, deletions or substitutions) required to change one word into the other.
//clustering - o pb ce se rezuma la gruparea unor obiecte in k clase
//distanta de editare= nr de operatii care trebuie facute ca sa transformam dintr-un cuvant, in altul
//am facut o lista de adiacenta intre noduri, fol de aceasta distanta Lev
//pt dist Lev am flosit programare dinamica
//am facut un vector de distanta, l am ordonat si am creat clasele, parcurcang vectorul
//am aflat dist Lev dintre 2 cuv, formand o matrice de dim celor 2 cuv si dist Lev va fi coltul cel mai din dreapta jos
//repetam ordonarea de n-k ori
//la final => k clase
//cand facem gruparea intre 2 cuvinte, ne asiguram ca ele sunt din clase diferite
//gradul de separare = urmatoarea muchie care apare cu cele 2 noduri din clase diferite
//pp ca gradul de separare dintre 2 cuvinte din clase dif este < dist Lev dintre 2 cuv din ac clasa <=> muchia cu gradul de sep <, ar fi fost luata inaintea mcuchiei dintre cele 2 cuv din ac
//clasa => nu ar mai fi fost grad de separare, ci o muchie dintre 2 cuv si am fi mers inainte. <=> muchia cu grad mai mare din ac clasa ar fi fost luata ca si grad de separare