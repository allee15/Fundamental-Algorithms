#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("disjoint.in");
ofstream g("disjoint.out");

int radacina(int x, vector<int> tata)
{
    if(tata[x]==0) return x;
    else return radacina(tata[x],tata);
}

int main()
{
    vector<int> tata;
    vector<int> multime;
    int n,m,c,x,y;
    f>>n>>m;

    tata.resize(n+m,0);
    multime.resize(n+m,0);
    for(int i=0;i<m;i++)
    {
        f>>c>>x>>y; //citim punctele si relatia dintre ele
        int r1= radacina(x,tata), r2=radacina(y,tata); //cautam radacina initiala pt x si y cititi de la tastatura
        if(c==1) //daca tipul relatiei este 1, facem conexiune intre x si y
        {
            if(multime[r1] < multime[r2]) tata[r1]=r2;
            else if(multime[r1]==multime[r2]) {tata[r1]=r2; multime[r2]+=1;}
                  else tata[r2]=r1;

        }
        else //altfel, verificam doar daca x si y sunt in aceeasi multime, adica daca au aceeasi radaina si afisam mesaj corespunzator
        {
            if(r1==r2) g<<"DA"<<endl;
            else g<<"NU"<<endl;
        }
    }
    f.close();
    g.close();

    return 0;
}