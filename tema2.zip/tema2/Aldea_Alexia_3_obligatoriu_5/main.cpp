#include <fstream>
#include <vector>
#include <iostream>
#include <queue>
#define inf 99999999

using namespace std;

ifstream f("catun.in");
ofstream g("catun.out");

int n,m,k;
vector<int> fortarete;
vector<pair<int,int>>distante;
vector<vector<pair<int,int>>> grefa;
vector<int> cost;
vector<int> viz;
vector<int> tata;
queue<pair<int,int>>q;

void citire()
{
    f>>n>>m>>k;
    int x,y,z;
    for(int i=0;i<k;i++)
    {
        f>>x; //formam lista de fortarete
        fortarete.push_back(x);
    }
    grefa.resize(n+1);
    cost.resize(n+1,inf);
    viz.resize(n+1,0);
    tata.resize(n+1,0);

    for(int i =0;i<m;i++)
    {
        f>>x>>y>>z; //citim muchiile si costul lor
        grefa[x].push_back(make_pair(y,z));
        grefa[y].push_back(make_pair(x,z));
    }

}

int main()
{
    citire();

    for(int i =0;i<fortarete.size();i++) //pt fortarete vom marca tatal, care va fi insasi fortareata
    {
        cost[fortarete[i]]=0;
        q.push(make_pair(0,fortarete[i]));
        tata[fortarete[i]]=fortarete[i];
    }

    while(!q.empty()) //aici cautam catunele si incercam sa gasim fortareata de care este legat fiecare catun
    {
        int nod= q.front().second;
        q.pop();

        if(viz[nod]==1)
            continue;
        viz[nod]=1;
        for(int i=0;i<grefa[nod].size();i++)
        {
            if(viz[grefa[nod][i].first]==0)
            {
                double newcost = cost[nod] + grefa[nod][i].second;
                if(newcost < cost[grefa[nod][i].first] || (newcost == cost[grefa[nod][i].first] && tata[nod]<tata[grefa[nod][i].first]))
                {
                    tata[grefa[nod][i].first]=tata[nod];
                    cost[grefa[nod][i].first]=newcost;
                    q.push(make_pair(newcost,grefa[nod][i].first));
                }
            }
        }
    }
    for(int i=0;i<k;i++) tata[fortarete[i]] =0;
    for(int i=1;i<=n;i++) g<<tata[i]<<" "; //afisam tatii pt fiecare catun

    f.close();
    g.close();

    return 0;
}