#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int distanta(vector<int>&n1, vector<int>&n2)
{
    return abs(n1[0]-n2[0])+ abs(n1[1]-n2[1]);
}

int main()
{
   vector<vector<int>>grefa;
   int rezultat=0;
   vector<int>distante;
   distante.resize(grefa.size(), INT_MAX);
   distante[0]=0;

    for (int i = 0; i < grefa.size(); ++i)
    {
        int minim=INT_MAX, p=0; //cautam distanta minima pt fiecare nod in graf
        for(int j=0;j<grefa.size();++j)
        {
            if(distante[j] != -1 && distante[j] < minim)
            {
                minim=distante[j]; p=j;
            }
        }
        rezultat += minim; //o adaugam la rezultat
        distante[p]= -1;
        for(int k=0;k<grefa.size();++k)
            if(distante[k] != -1)
                distante[k] = min(distante[k], distanta(grefa[p],grefa[k]));
    }
    cout<<rezultat;
    return 0;
}
