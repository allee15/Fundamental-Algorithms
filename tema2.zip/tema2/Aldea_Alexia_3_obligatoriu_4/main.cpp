#include <fstream>
#include <iostream>
#include <vector>
#include <queue>

using namespace std;

ifstream f("dijkstra.in");

int n,start,end;
vector<vector<int>> edges;
vector<double> succProb;

int main()
{
    vector<pair<int,double>> adj[n];
    for(int i=0;i<edges.size();i++)
    {
        int x=edges[i][0];
        int y=edges[i][1];
        adj[x].push_back(make_pair(y,succProb[i]));
        adj[y].push_back(make_pair(x,succProb[i])); //luam perechea (x,y) si facem muchie bidirectionala intre x si y
    }
    queue<pair<double,int>> q;
    vector<double>distante(n,0.0);
    q.push(make_pair(1.0,start)); //cautam drumul cerut in cerinta
    distante[start]=1.0; //marcam distanta cu 1, pornind din nodul de start
    while(!q.empty())
    {
        double cost= q.front().first;
        int nod= q.front().second;
        q.pop();
        for(int i=0;i<adj[nod].size();i++)
            if(distante[adj[nod][i].first]< adj[nod][i].second*cost)
            {
                distante[adj[nod][i].first]=adj[nod][i].second*cost;
                q.push(make_pair(distante[adj[nod][i].first], adj[nod][i].first));
            } //cautam distanta optima
    }
    cout<<distante[end]; //afisam distanta din end
}