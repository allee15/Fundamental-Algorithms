#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <bits/stdc++.h>

using namespace std;

ifstream f("retea2.in");
ofstream g("retea2.out");

struct centrala {int x,y;} v[2000];

int n,m;
float total;

int gata(vector<int> viz)
{
    for(int i=0;i<n+m;i++)
        if(viz[i]==0)
            return 0;
    return 1;
}

float Prim( vector<vector<pair<int,float>>>grafbloc)
{
    vector<int> viz;
    viz.resize(n+m,0);
    vector<float> distante;
    distante.resize(n+m,99999);
    vector<int> tata;
    tata.resize(n+m,0);
    distante[0]=0;

    while(gata(viz)!=1) //formam arborele partial de cost minim
    {
        int nod = min_element(distante.begin(), distante.end())-distante.begin();
        viz[nod]=1;
        for(int i=0;i!=grafbloc[nod].size();i++)
        {
            if(viz[grafbloc[nod][i].first]==0 && grafbloc[nod][i].second < distante[grafbloc[nod][i].first])
            {
                distante[grafbloc[nod][i].first]=grafbloc[nod][i].second;
                tata[grafbloc[nod][i].first]=nod;

                if(nod >= n && grafbloc[nod][i].first<n && tata[nod]<n && distante[nod]>distante[grafbloc[nod][i].first])
                    //stergem conexiunea nodului de cost cel mai mare
                    for(int k=0;k!=grafbloc[tata[nod]].size();k++)
                        if(grafbloc[tata[nod]][k].first == nod)
                            total-=grafbloc[tata[nod]][k].second; //in cazul in care gasim o conexiune de distanta mai mica, o stergem pe cea curenta.

            }
        }
        if(nod >= n) { //adaugam la total distanta lui nod doar daca este bloc, nu centrala
            total+=distante[nod];
        }
        distante[nod]=99999;
    }
    return total;
}

int main()
{
    vector<vector<pair<int,float>>>grafbloc;

    int a,b;
    f>>n>>m;
    grafbloc.resize(n+m);

    for(int i=0;i<n;i++)
        f>>v[i].x>>v[i].y; //citim centralele si le stocam intr-un struct

    for(int i=0;i<m;++i)
    {
        f>>a>>b; //citim blocurile
        v[n+i].x=a;
        v[n+i].y=b;

        for(int j=0;j<n;++j) //facem distanta dintre 2 puncte
        {//aici facem ca fiecare bloc sa se lipseasca de fiecare centrala
            grafbloc[j].push_back(make_pair(n+i, sqrt((a-v[j].x)*(a-v[j].x)+ (b-v[j].y)* (b-v[j].y))));
            grafbloc[n+i].push_back(make_pair(j, sqrt((a-v[j].x)*(a-v[j].x)+ (b-v[j].y) *(b-v[j].y))));
        }
        for(int k=0;k<i;k++)
        {//facem ca fiecare bloc sa se lipeasca de toate celelalte blocuri
            grafbloc[n+i].push_back(make_pair(n+k, sqrt((a-v[n+k].x)*(a-v[n+k].x)+ (b-v[n+k].y)* (b-v[n+k].y))));
            grafbloc[n+k].push_back(make_pair(n+i, sqrt((a-v[n+k].x)*(a-v[n+k].x)+ (b-v[n+k].y)* (b-v[n+k].y))));
        }
    }

    float rezultat= Prim(grafbloc); //returnam arborele partial de cost minim
    g<<fixed<<showpoint;
    g<<setprecision(6)<<rezultat<<'\n';

    return 0;
}