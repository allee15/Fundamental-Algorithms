#include <fstream>
#include <vector>

using namespace std;

ifstream f("easygraph.in");
ofstream g("easygraph.out");

vector<vector<int> > a;
int n,m,t;
vector<int> d;
vector<int> v;
vector<int>viz;
int inf=100000001;

void citire()
{
    int x,y;
    f>>n>>m; //citim graful

    v.resize(n+1);
    a.resize(n+1);
    for(int i=1;i<=n;i++)
        f>>v[i];
    for(int i=1;i<=m;i++)
    {
        f>>x>>y;
        a[x].push_back(y);
    }
}

void DFS(int x)
{
    d[x]=max(d[x], v[x]);
    viz[x]=1;
    for(int i:a[x]){
        if(viz[i]==0)
            DFS(i);
        d[x]=max(d[x],v[x]+d[i]);}
}

void solve() //cautam suma maxima in graf, folosindu-ne de un dfs
{
    int aux=-inf;
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
            DFS(i);
        aux=max(aux,d[i]);
    }
    g<<aux<<'\n';
}

int main()
{
    f>>t;
    citire();
    while(t>0) //cat timp avem teste disponibile
    {
        t--;
        //restartam tot vectorii
        d.clear();
        viz.clear();
        d.resize(n+1,-inf);
        viz.resize(n+1,0);
        solve();
    }

    f.close();
    g.close();
    return 0;
}