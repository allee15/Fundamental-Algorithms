#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

class Solution {
public:
    vector<int>tata;

    int find(int node) {
        if(tata[node] == node) return node;
        return tata[node] = find(tata[node]); //cautam tatal pt node
    }

    void u(int node1, int node2) { //cautam tatii initiali pt node1 si node2
        int aux1 = find(node1);
        int aux2 = find(node2);
        tata[aux1] = aux2;
    }
    vector<bool> distanceLimitedPathsExist(int n, vector<vector<int>>& edgeList, vector<vector<int>>& queries) {
        tata.resize(n);
        for(int i = 0; i < n; ++i) tata[i] = i; //initial fiecare nod este propriul sau tata
        int N = edgeList.size();
        vector<bool>res(queries.size());

        sort(edgeList.begin(), edgeList.end(), [](auto &aux1, auto &aux2) {
            return aux1[2] < aux2[2];
        }); //sortam vectorul edgeList in functie de costul fiecarei muchii

        int i = 0;
        for(auto& q: queries) {
            q.push_back(i);
            ++i;
        }

        sort(queries.begin(), queries.end(), [](auto &aux1, auto &aux2) {
            return aux1[2] < aux2[2];
        }); //sortam vectorul queries in functie de distante

        i = 0;
        for(auto q: queries) { //verificam pt fiecare pereche din queries daca putem gasi in graf un drum mai mic ca si costul dat in queries si dam mesaj
            //corespunzator
            int limit = q[2];
            while(i < N and edgeList[i][2] < limit) {
                u(edgeList[i][0], edgeList[i][1]);
                i++;
            }
            if(find(q[0]) == find(q[1])) res[q[3]] = true;
            else res[q[3]] = false;
        }
        return res;
    }
};